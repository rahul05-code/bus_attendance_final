import 'package:flutter/material.dart';
import 'api_service.dart';

class RegisterPage extends StatelessWidget {
  final nameCtrl = TextEditingController();
  final phoneCtrl = TextEditingController();
  final passCtrl = TextEditingController();
  final stopCtrl = TextEditingController();
  String? city, bus;

  final cities = ["Morbi", "Rajkot", "Gondal", "Tankara", "Jasdal", "Wankaner"];
  final buses = [
    "Morbi(Big)",
    "Morbi(Small)",
    "Gondal(Big)",
    "Gondal(Small)",
    "Rajkot",
    "Jasdal",
    "Wankaner"
  ];

  void register(BuildContext context) async {
    final res = await ApiService.register(nameCtrl.text, phoneCtrl.text, city!,
        bus!, stopCtrl.text, passCtrl.text);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content:
            Text(res["status"] == "success" ? "Registered!" : res["message"])));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Register")),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: ListView(children: [
          TextField(
              controller: nameCtrl,
              decoration: InputDecoration(labelText: "Name")),
          TextField(
              controller: phoneCtrl,
              decoration: InputDecoration(labelText: "Phone")),
          DropdownButtonFormField(
              value: city,
              items: cities
                  .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                  .toList(),
              onChanged: (v) => city = v),
          DropdownButtonFormField(
              value: bus,
              items: buses
                  .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                  .toList(),
              onChanged: (v) => bus = v),
          TextField(
              controller: stopCtrl,
              decoration: InputDecoration(labelText: "Stop")),
          TextField(
              controller: passCtrl,
              obscureText: true,
              decoration: InputDecoration(labelText: "Password")),
          ElevatedButton(
              onPressed: () => register(context), child: Text("Register")),
        ]),
      ),
    );
  }
}
